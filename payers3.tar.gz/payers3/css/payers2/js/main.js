$(function() {
   'use strict'

    // Sign up Full Window

    $('.signup').height($(window).height());

});

 $(function () {
 	'use strict'
 	// var winH = $
 	// (window).innerheight(),
 	// headerH = $('header').innerheight(),
 	// footerH = $('footer').innerheight(),
 	$('.jubmtron').height($(window).height());

});
